#ifndef __KEY_H
#define __KEY_H	 
#include "sys.h" 


//KEY�˿ڶ���

#define KEY1			GPIO_Pin_Get(GPIOG,PIN1)	
#define KEY2 		  GPIO_Pin_Get(GPIOG,PIN2)	//PH2 
//#define KEY1 		GPIO_Pin_Get(GPIOH,PIN2)	//PH2 
//#define KEY2 		GPIO_Pin_Get(GPIOC,PIN13)	//PC13
//#define WK_UP 		GPIO_Pin_Get(GPIOA,PIN0)	//PA0 

#define KEY1_PRES 	1	//KEY0����
#define KEY2_PRES	2	//KEY1����
//#define KEY2_PRES	3	//KEY2����
//#define WKUP_PRES   4	//KEY_UP����(��WK_UP)


//KEY_led�˿ڶ���
#define KEY_led1(x)			GPIO_Pin_Set(GPIOF,PIN11,x)		// KEY_led1
#define KEY_led2(x)			GPIO_Pin_Set(GPIOF,PIN12,x)		// KEY_led2
#define KEY_led3(x)			GPIO_Pin_Set(GPIOF,PIN13,x)		// KEY_led3
#define KEY_led4(x)			GPIO_Pin_Set(GPIOF,PIN14,x)		// KEY_led4
#define KEY_led5(x)			GPIO_Pin_Set(GPIOF,PIN15,x)		// KEY_led5


void KEY_Init(void);	//��ʼ��	
u8 KEY_Scan(u8);  		//����ɨ�躯��
#endif

















