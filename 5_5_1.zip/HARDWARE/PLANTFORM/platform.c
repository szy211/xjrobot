#include "platform.h" 
#include "timer.h"
#include "usart.h"
#include "sys.h"
#include "dataprocess.h"

//////////////////////////////////////////////////////////////////////////////////	 
									  

void PLatForm_Init(void)
{   	  
	RCC->AHB1ENR|=1<<4;	//ʹ��PORTEʱ�� 	
	GPIO_Set(GPIOE,PIN15|PIN14|PIN13|PIN12|PIN11,GPIO_MODE_OUT,GPIO_OTYPE_PP,GPIO_SPEED_100M,GPIO_PUPD_PU); 
	// PLATFORMPUL(0);
  // PLATFORMDIR(0);	
    //GPIO_PE15(0);			
    //GPIO_PE14(0);		
   // GPIO_PE12(0);			 
   // GPIO_PE11(0);			
   // GPIO_PE10(0);
}                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                
    


 static u8 platwavesta=0;

 //int i=0;

 void PLatForm_Wave(void)	
{
	if(platCountTime>PLATCOUNT)   // 
		
	{
	  PLATFORMPUL(platwavesta^=1);			
      platCountTime=0;
			//i++;
	
	}	
}	
void PlantFormHight_Service()
	
{   
	if(platformmode==0)  // 0�ֶ�����ģʽ
	{
	  PlantForm_HandMode();
	}
	if(platformmode==1)  //1�Զ�����ģʽ��־
	{
	  PlantForm_AutoMode();
	}
}
	
int32_t   PlatformpulCount=0;
int8_t Pre_PlatformHeight=0;


uint8_t  heightauto;
uint8_t  heighthand;
void PlantForm_AutoMode(void)//�Զ�����ƽ̨��
{   
	//int8_t heighetdiffvalue=0;
	
	   //int8_t tempheight;
    // tempheight= PlatformHeight;

	  if(Pre_PlatformHeight>=PlatformHeight)  //�½�
	    {
		 //heighetdiffvalue=Pre_PlatformHeight-PlatformHeight;
		   
			 
		     if(PlatformpulCount>PlatformHeight*HeightTOPulC)
		   {
				PLATFORMDIR(0);
			  PLatForm_Wave();
			  PlatformpulCount--;
				heighthand=PlatformpulCount/HeightTOPulC;
			  if(PlatformHeight*HeightTOPulC==PlatformpulCount)
		      {
		       Pre_PlatformHeight=PlatformHeight;
		      }
			  
		   }
		   
	   }
	 else
	   {    //����   ��ǰֵ<�·�ֵ
		   //heighetdiffvalue=PlatformHeight-Pre_PlatformHeight;
		   PLATFORMDIR(1); 
			 if(PlatformpulCount<PlatformHeight*HeightTOPulC)
		   {
			   PLatForm_Wave();
			   PlatformpulCount++;
				 heighthand=PlatformpulCount/HeightTOPulC;
				  if(PlatformHeight*HeightTOPulC==PlatformpulCount)
		       {
		         Pre_PlatformHeight=PlatformHeight;
		       }	 
					 
		   }
	 
		   
		}
		
		 
}

int32_t PlatformpulHandCount=0;
int32_t PlatformpulheightHandCount=0;
void PlantForm_HandMode(void)
{
	  
 if(PlatformpulHandCount<PlatformHeight*HeightTOPulC)
		{
			if(platforupdowmsta==1)
			{
				PlatformpulheightHandCount++;
			}
			if(platforupdowmsta==0)
			{
				PlatformpulheightHandCount--;
			}
			PlatformpulHandCount++;
			PLatForm_Wave();
			if(PlatformpulHandCount==PlatformHeight*HeightTOPulC)
		       {
		         PlatformpulHandCount=0;
		       }
				 
		}
		heighthand=PlatformpulheightHandCount/HeightTOPulC;
	
}
	
	

	
	
	
	
	
	

//	 if(PlantFormHight==0)
//	{
//	//USART1_Transmi_Data(WriteP_Data_Fusion->bytes,sizeof(WriteP_Data_Fusion->bytes));
//	   PlantFormHight=255;
//	}
//	else if(PlantFormHight>0&&(PlantFormHight!=255))                //�����ںϺ�����Ƕ��ϴ�
//	{
//		
//       for (int i=0;i<PlantFormHight;i++) 
//		       {
// 		         PlantFormHight_ToPul();
//						 
//			   }
//	}
//	



//void PlantFormHight_ToPul(void)
//	
//{

//      int PULCount=1000;
//	    for (int i=0;i<PULCount;i++)
//       {
//			PLatForm_Wave();
//					
//        }
//}



