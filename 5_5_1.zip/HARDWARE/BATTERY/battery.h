#ifndef __BATTERY_H
#define __BATTERY_H


#include "sys.h"
#include "stdio.h"	
 
#ifdef __cplusplus
 extern "C" {
#endif
	 
#define  RS232_REC_LEN	 20  
//#define  RS232_EN()	   GPIO_Pin_Set(GPIOE,PIN2,x)	
	 
#define InvalidFLag  2
	 
#define HI(n) ((n)>>8)
#define LOW(n) ((n)&0xff)
	 
u16 CRC_Compute(u8 * pushMsg,u8 usDataLen);
	 
void RS232_Init(u32 pclk2,u32 bound);
void RS232_Send_Data(u8 *buf,u8 len);
void RS232_Receive_Data(u8 *buf,u8 *len);	


void RS232_TX_Service(void);
void RS232_RX_Service(void);
	 
void Master_Service(u8 SlaverAddr,u8 Fuction,u16 StartAddr,u16 ValueOrLenth);
void Master_03_Slove( u8 board_adr,u16 start_address,u16 lenth );
void Master_06_Slove(u8 board_adr,u16 start_address, u16 value);
void Modbus_03_Solve(void);

void clean_rebuff(void);


extern u8 CurState;
extern u8 ChrgState;
extern u32 Voltage;
void Battery_Message_Get(void);




#endif



