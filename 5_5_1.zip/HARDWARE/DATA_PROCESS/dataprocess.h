#ifndef __DATAPROCESS_H
#define __DATAPROCESS_H


#ifdef __cplusplus
 extern "C" {
#endif
	 
#include "stm32f7xx.h"
#include "sys.h"	 
	 
//�����붨��
#define Checksum_Error 0x01             //У��˴���
#define Length_information_Error 0x02   //���ȴ���
#define Undefined_Order_Error 0x03      //�޶������
#define Header_Error 0x04               
#define Brake_instructions_Error 0x05	  
	 
#define CHECK_DATA_MAX_LEN  20

#define UsartCheckInform_Initializer {0,0,0,0,{0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0}}





#define USART1DATARESCOUNT  1000   // 10 ms
#define MESSAGETOPCCNT    10000  // 100ms ����һ��

typedef struct
{
	uint8_t  Head1;
	uint8_t  Head2;
	uint8_t  Lenghth;
	uint8_t  Order;
	uint8_t  data[CHECK_DATA_MAX_LEN];
	uint8_t  SumCheck;
}UsartCheckInform;

extern uint8_t DataFrequency;
extern uint8_t IMU_DataFrequency;
extern uint8_t  PlantFormHight;
extern uint32_t Car_Motion_status_Fre;
extern uint32_t Data_Fusion_Fre;
extern uint32_t IMU_Data_Fre;
extern int8_t PlatformHeight;
extern uint8_t platformmode;
extern uint8_t platforupdowmsta;

//7_24
extern int16_t PlatformCFromPC_1;
//extern volatile int16_t PlatformC_1;
extern uint8_t PlatformState;

static const uint8_t USART1DATARETIMER=200;  //   Tim3��ʱ��10us����һ��    ����10��=20us��	
	 

	 
	 
//*************ת��С���ϴ���Ϣ*********************//	 
typedef union
{
	struct
	{
		__IO  uint8_t  Head1;
		__IO  uint8_t  Head2;
		__IO  uint8_t  Lenghth;
		__IO  uint8_t  Order;
		__IO  uint8_t  Error;
		__IO  uint8_t  SumCheck;
	}detail;
	uint8_t bytes[6];
}Error_Massage;	 

typedef union
{
	struct
	{
		__IO  uint8_t  Head1;
		__IO  uint8_t  Head2;
		__IO  uint8_t  Lenghth;
		__IO  uint8_t  Order;
		__IO  uint8_t  Return_Data;
		__IO  uint8_t  SumCheck;
	}detail;
	uint8_t bytes[6];
}Return;

typedef union
{
	struct
	{
		__IO  uint8_t  Head1;
		__IO  uint8_t  Head2;
		__IO  uint8_t  Lenghth;
		__IO  uint8_t  Order;
		__IO  uint8_t  Return_Data;
		__IO  uint8_t  SumCheck;
	}detail;
	uint8_t bytes[6];
}Return_set;

typedef union
{
	struct
	{
		__IO  uint8_t  Head1;
		__IO  uint8_t  Head2;
		__IO  uint8_t  Lenghth;
		__IO  uint8_t  Order;
		__IO  uint8_t  Return_Data;
		__IO  uint8_t  Distance;
		__IO  uint8_t  SumCheck;
	}detail;
	uint8_t bytes[6];
}Return_Odom;
//7_24_����ƽ̨
typedef union
{
	struct
	{
		__IO uint8_t  Head1;
		__IO uint8_t	Head2;
		__IO uint8_t	Lenghth;
		__IO uint8_t	order;
		__IO uint8_t	Return_Data;
		__IO uint8_t	Mode;   // �հ�û����
		__IO short      Hight;
		__IO uint8_t	SumCheck;		
	}detail;
	uint8_t bytes[9];
}Return_Platform;
/*****************/

//���峬����������������
typedef union
{
	struct
	{	
		__IO  uint8_t  Head1;
		__IO  uint8_t  Head2;
		__IO  uint8_t  Lenghth;
		__IO  uint8_t  Order;
		__IO  uint16_t  Ultrasonic1;
		__IO  uint16_t  Ultrasonic2;
		__IO  uint16_t  Ultrasonic3;
		__IO  uint16_t  Ultrasonic4;
		__IO  uint16_t  Ultrasonic5;
		__IO  uint16_t  Ultrasonic6;
		__IO  uint16_t  Ultrasonic7;
		__IO  uint16_t  Ultrasonic8;
//		__IO  uint8_t  Ultrasonic1_H;
//		__IO  uint8_t  Ultrasonic1_L;
//		__IO  uint8_t  Ultrasonic2_H;
//		__IO  uint8_t  Ultrasonic2_L;
//		__IO  uint8_t  Ultrasonic3_H;
//		__IO  uint8_t  Ultrasonic3_L;
//		__IO  uint8_t  Ultrasonic4_H;
//		__IO  uint8_t  Ultrasonic4_L;
//		__IO  uint8_t  Ultrasonic5_H;
//		__IO  uint8_t  Ultrasonic5_L;
//		__IO  uint8_t  Ultrasonic6_H;
//		__IO  uint8_t  Ultrasonic6_L;
		__IO  uint8_t  SumCheck;
	}detail;
	uint8_t bytes[21];//4+2*8+1=21���ֽ�
}Ultrasonic_Massage;

//�������崫����������������
typedef union
{
	struct
	{	
		__IO  uint8_t  Head1;
		__IO  uint8_t  Head2;
		__IO  uint8_t  Lenghth;
		__IO  uint8_t  Order;
		__IO  float CO;
		__IO  float CO2;
		__IO  float SO2;
		__IO  uint8_t  SumCheck;
	}detail;
	uint8_t bytes[17];//4*1+3*4+1=17���ֽ�
}Gas_Message;

//��������Ϣ������������
typedef union
{
	struct
	{	
		__IO  uint8_t  Head1;
		__IO  uint8_t  Head2;
		__IO  uint8_t  Lenghth;
		__IO  uint8_t  Order;
		__IO  uint8_t  Charge_Switch_Status;//��翪��״̬ 0x00�ر�״̬ 0x01��״̬
		__IO  uint8_t  Electric_Quantity_Percentage;//�����ٷֱ�
		__IO  uint8_t  Whether_Charge;//�Ƿ��� 0x00������ 0x02���ڳ�� 0x04��Ҫ���
	}detail;
	uint8_t bytes[7];//7���ֽ�
}Battery_Message;


typedef union
{
	struct
	{	
		__IO  uint8_t  Head1;
		__IO  uint8_t  Head2;
		__IO  uint8_t  Lenghth;
		__IO  uint8_t  Order;
		__IO  uint8_t  LED_1;
		__IO  uint8_t  LED_2;
		__IO  uint8_t  LED_3;
		__IO  uint8_t  LED_4;
		//__IO  uint8_t  LED_5;
		__IO  uint8_t  Charge;//Charge_Switch_Status;//��翪��״̬ 0x00�ر�״̬ 0x01��״̬
		__IO  uint8_t  Charge_status;//Whether_Charge;//�Ƿ��� 0x00������ 0x02���ڳ�� 0x04��Ҫ���
		__IO  uint8_t  Power;//Electric_Quantity_Percentage;//�����ٷֱ�
		__IO  uint8_t  Error;
		__IO  uint8_t  SumCheck;
	}detail;
	uint8_t bytes[13];
}Motion_status_Massage;
//=====================End==================================//

//=======================�����ں��ϴ�=========================//

typedef struct {
	
	__IO  uint8_t  Head1;
	__IO  uint8_t  Head2;
	__IO  uint8_t  Lenghth;
	__IO  uint8_t  Order;
    __IO  float  DistanceX;
	__IO  float  DistanceY;
	__IO  float  Angular;
	__IO  float  SpeedX;
	__IO  float  SpeedY;
	__IO  float  SpeedAng;
	__IO  uint8_t  SumCheck;
}Position_str;

typedef union{
	Position_str Detial;
	uint8_t bytes[29];
}Position;

typedef struct
{
	__IO  uint8_t  Head1;
	__IO  uint8_t  Head2;
	__IO  uint8_t  Lenghth;
	__IO  uint8_t  Order;
    __IO  float  Pitch;
	__IO  float  Yaw;
	__IO  float  Roll;
	__IO  uint8_t  SumCheck;
}IMU_Data_str;

typedef union{
	IMU_Data_str Detial;
	uint8_t bytes[17];
}IMU_Data_inf;
//=====================End==================================//


//===================��λ����Ϣ���·�װ=======================//
struct Control_Str{
	
	__IO  uint8_t  Header;
	__IO  uint8_t  Control;
	__IO  uint8_t  Lin_Speed_H;
	__IO  uint8_t  Lin_Speed_L;
    __IO  uint8_t  Angular_Speed_H;
	__IO  uint8_t  Angular_Speed_L;
	__IO  uint8_t  Stop;
	__IO  uint8_t  CRC8;
	__IO  uint8_t  Tail;
};

typedef union Control_Un
{
	struct Control_Str Detail;
	uint8_t bytes[9];
}ControlDef;

struct Configuration_Str{
	
	__IO  uint8_t  Header;
	__IO  uint8_t  Control;
	__IO  uint8_t  LED_1;
	__IO  uint8_t  LED_2;
    __IO  uint8_t  LED_3;
	__IO  uint8_t  LED_4;
	__IO  uint8_t  LED_5;
	__IO  uint8_t  FRQ_1;
	__IO  uint8_t  FRQ_2;
	__IO  uint8_t  CRC8;
	__IO  uint8_t  Tail;
};
typedef union Configuration_Un
{
	struct Configuration_Str Detail;
	uint8_t bytes[11];
}ConfigDef;
//========================End===================================//


extern IMU_Data_inf *SendP_Data_IMU,*WriteP_Data_IMU;
extern Return_Odom Message_Return_Odom;	  
extern Return Massage_Return;


void Usart1_Data_Analyse(void);
void Massage_Timing_To_Pc(void);

 
void UltrasonicSend(void);
void TransPCarMotionstatus(void);
void ImuaDataSend(void);
void ImuaDataSend(void);
void GasSend(void);




#endif

















