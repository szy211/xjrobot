#include "key.h" 
#include "delay.h"
//////////////////////////////////////////////////////////////////////////////////	 
									  
////////////////////////////////////////////////////////////////////////////////// 	 

void KEY_LED_Init(void)
	
{
     RCC->AHB1ENR|=1<<5;	//ʹ��PORTFʱ��	
	   GPIO_Set(GPIOF,PIN11|PIN12|PIN13|PIN14|PIN15,GPIO_MODE_OUT,GPIO_OTYPE_PP,GPIO_SPEED_100M,GPIO_PUPD_PU); 
     
     	KEY_led1(0);
			KEY_led2(0);
			KEY_led3(0);
			KEY_led4(0);
			KEY_led5(0);
}
void KEY_Init(void)
{   	  

   RCC->AHB1ENR|=1<<6;	//ʹ��PORTGʱ��	

	 GPIO_Set(GPIOG,PIN1,GPIO_MODE_IN,0,0,GPIO_PUPD_PU); 
   GPIO_Set(GPIOG,PIN0,GPIO_MODE_IN,0,0,GPIO_PUPD_PU); 
	 //KEY1(1);
	 KEY_LED_Init();
}








