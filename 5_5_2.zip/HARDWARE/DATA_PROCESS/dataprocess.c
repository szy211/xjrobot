#include <string.h>
#include "dataprocess.h"
#include "sys.h"
#include "usart.h"
#include "task.h"
#include "imu.h"
#include "can.h"
#include "can_drive.h"
#include "timer.h"
#include "platform.h"
#include "stdint.h"
#include "battery.h"
#include "Platform_1.h"
//��������
extern u8 Electric_Quantity_Percentage;
extern u8 Whether_Charge;

uint8_t DataFrequency;
uint8_t SpeedFrequency;
uint8_t IMU_DataFrequency;
uint8_t Car_Configuration_FRQ_1;
uint8_t Car_Configuration_FRQ_2;
int8_t  PlatformHeight;

uint8_t PlantFormHight;
uint8_t platformmode;
uint8_t platforupdowmsta;
uint32_t Car_Motion_status_Fre;
uint32_t Data_Fusion_Fre;
uint32_t IMU_Data_Fre;
uint8_t PlatformState;// 0:�½���1��������2��ֹͣ,4:��ֹ�ٴε���
int send_num_order_return = 0;

//�ṹ�嶨��
ControlDef Car_Move_Conrol;
ConfigDef Car_Configuration;
Return Massage_Return;
Return_set Massage_Return_set;
Return Massage_Return;
Return_Odom Message_Return_Odom;
Error_Massage OutPut_Error_Massage;
//����ƽ̨
Return_Platform Massage_Return_Platform;


//�ṹ��ָ��
//Ultrasonic_Massage Car_Ultrasonic_Massage[2];
//Ultrasonic_Massage *SendP_Ultrasonic=&Car_Ultrasonic_Massage[0],*WriteP_Ultrasonic=&Car_Ultrasonic_Massage[1];

//Motion_status_Massage Car_Motion_status_Massage[2];
//Motion_status_Massage *SendP_Car_Motion_status=&Car_Motion_status_Massage[0],*WriteP_Car_Motion_status=&Car_Motion_status_Massage[1];

Position Car_Position[2];
Position *SendP_Data_Fusion=&Car_Position[0],*WriteP_Data_Fusion=&Car_Position[1];

IMU_Data_inf IMU_Data_Detial[2];
IMU_Data_inf *SendP_Data_IMU=&IMU_Data_Detial[0],*WriteP_Data_IMU=&IMU_Data_Detial[1];


//���ݳ���������λ��
void Output_Error(uint8_t error)
{
	OutPut_Error_Massage.detail.Head1=0xCC;
	OutPut_Error_Massage.detail.Head2=0x33;
	OutPut_Error_Massage.detail.Lenghth=0x03;
	OutPut_Error_Massage.detail.Order=0xFF;
	OutPut_Error_Massage.detail.Error=error;
	OutPut_Error_Massage.detail.SumCheck=(uint8_t)(OutPut_Error_Massage.detail.Order+OutPut_Error_Massage.detail.Error);
	//����1���ݷ���
	USART1_Transmi_Data(OutPut_Error_Massage.bytes,sizeof(OutPut_Error_Massage));

}



int Check_Sum(uint8_t pData[],int num)
{
	uint16_t Sum=0;
	int count=3;
	for(count=3;count<num-1;count++)
	{
		Sum=(Sum+pData[count]);
	}
	if(pData[num-1]==((uint8_t)(Sum & 0xff)) )
		return 1;
	else
		return 0;
}


void UsartCheckInformInit(UsartCheckInform *check_inform)
{
    check_inform->Head1 = 0;
    check_inform->Head2 = 0;
    check_inform->Lenghth = 0;
    check_inform->Order = 0;
    memset(check_inform->data, 0, sizeof(check_inform->data));
}


//����1���ݽ��ս���
int16_t speedlinedata=0,speedangledata=0;
//int constspeed_k=1722;  //�ٶ��·�����   ��1��/��ʱ �����Ҫת1722 ת
//float constwheel_interval=0.248f;               // �������
const float CONST_SPEED=30.0f * REDUCTION_RATIO / PI / WHEEL_RADIUS;
int16_t speed12_send,speed34_send,cur_speed12,cur_speed34;  // Ҫ�·����ٶ� �ͽ��������ٶ�   ���speed_34  �Ҳ�speed_12 

void Usart1_Data_Analyse(void)
{ 
  if(Usart1DataResCount>USART1DATARESCOUNT)
  {
	   Usart1DataResCount=0;
       if(usart1_send.si_ze > 5)
		{
        int i = 0;
        UsartCheckInform check_inform;
		    memset(&check_inform, 0, sizeof(UsartCheckInform));
        if (UsartQueuePop(&usart1_send, &check_inform.Head1) == USART_QUEUE_OK)
        {
            //printf("-----------------head1--------------------------");
            if (check_inform.Head1 == 0xCC) //   head1;
            {
                check_inform.data[0] = 0xCC;
                //printf("-----------------head1--------------------------");
                if (UsartQueuePop(&usart1_send, &check_inform.Head2) == USART_QUEUE_OK)
                {
                    if (check_inform.Head2 == 0x33) // head2
                    {
                        check_inform.data[1] = 0x33;
                        //printf("-----------------head2--------------------------");
                        if (UsartQueuePop(&usart1_send, &check_inform.Lenghth) == USART_QUEUE_OK)
                        {
                            check_inform.data[2] = check_inform.Lenghth;

                          if(check_inform.Lenghth>=0x01&&check_inform.Lenghth<=0x10) //
                           {
								for (i = 0; i < check_inform.Lenghth; i++)
								{
									UsartQueuePop(&usart1_send, &check_inform.data[i + 3]);
								}
								if (Check_Sum(check_inform.data, check_inform.Lenghth + 3) == 1) //У����ȷ
								{
									switch (check_inform.data[3])
									{
										case 0x01://  �˶�����ָ��
											if(state_yksp!=1)
											{
											   if (check_inform.data[8] == 0)
											   {
													 speedlinedata = (int16_t)(((uint16_t)check_inform.data[5] << 8) + (uint16_t)check_inform.data[4]);
													 speedangledata = (int16_t)(((uint16_t)check_inform.data[7] << 8) + (uint16_t)check_inform.data[6]);
													 
													 carsport_state=0;

													 speed34_send=-CONST_SPEED*(speedlinedata-DIFFERENCE_LEFT_RIGHT_WHEELS_HALF*speedangledata)/1000.0;    // �����·���λΪ��/��
													 speed12_send=CONST_SPEED*(speedlinedata+DIFFERENCE_LEFT_RIGHT_WHEELS_HALF*speedangledata)/1000.0;


//													if((cur_speed12!=speed12_send)||(cur_speed34!=speed34_send))
//													{
													 Motor_Velocity(Motor1_Drive_ID,(uint16_t)(speed12_send));
													 delay_ms(1);
													 Motor_Velocity(Motor2_Drive_ID,(uint16_t)(speed12_send));
													 delay_ms(1);
													 Motor_Velocity(Motor3_Drive_ID,(uint16_t)(speed34_send));
													 delay_ms(1);
													 Motor_Velocity(Motor4_Drive_ID,(uint16_t)(speed34_send));
													 delay_ms(1);
//													 cur_speed12=speed12_send;
//													 cur_speed34=speed34_send;	
//													}	 
												}
												if(check_inform.data[8] == 1)
												{	
												 //�ٶ�Ϊ0С��ֹͣ
													 Motor_Velocity(Motor1_Drive_ID,(uint16_t)(0));
													 Motor_Velocity(Motor2_Drive_ID,(uint16_t)(0));
													 Motor_Velocity(Motor3_Drive_ID,(uint16_t)(0));
													 Motor_Velocity(Motor4_Drive_ID,(uint16_t)(0));
												}
												//===============================�����ػ������˶�����ָ����ճɹ�============================//
												Massage_Return.detail.Head1=0xCC;
												Massage_Return.detail.Head2=0x33;
												Massage_Return.detail.Lenghth=0x03;
												Massage_Return.detail.Order=0x01;
												Massage_Return.detail.Return_Data=0x41;
												Massage_Return.detail.SumCheck=(uint8_t)(Massage_Return.detail.Order+Massage_Return.detail.Return_Data);
												//����1����
												USART1_Transmi_Data(Massage_Return.bytes,sizeof(Massage_Return));			
												//================================end=============================================//   
											}
										 break ;				
									  case 0x02: //ƽ̨����ָ��
											Car_Configuration_FRQ_1=check_inform.data[9];       //��������ϢƵ��
											Car_Configuration_FRQ_2=check_inform.data[10];      // �˶�ƽ̨�ϴ�Ƶ��
										  //						//===============================�����ػ�����ָ�����������Ϣ=============================//
											Massage_Return.detail.Head1=0xCC;
											Massage_Return.detail.Head2=0x33;
											Massage_Return.detail.Lenghth=0x03;
											Massage_Return.detail.Order=0x02;
											Massage_Return.detail.Return_Data=0x42;
											Massage_Return.detail.SumCheck=(uint8_t)(Massage_Return.detail.Order+Massage_Return.detail.Return_Data);
											USART1_Transmi_Data(Massage_Return.bytes,sizeof(Massage_Return));
										 break;
										case 0x11: // �źŴ�����Ԫ �������ݲ�ѯ ���ں���Ϣ�ϴ�Ƶ���趨  
											DataFrequency=check_inform.data[4];   //��ϢƵ���ϴ�ȷ��  0Ϊ���β�ѯ
											SpeedFrequency=check_inform.data[5];
											break;
										case 0x12://��̼�����ָ��
											X=0;
											Y=0;
											//Distance_L=0;
											//===============================�����ػ�������������Ѿ�����============================//
											Massage_Return.detail.Head1=0xCC;
											Massage_Return.detail.Head2=0x33;
											Massage_Return.detail.Lenghth=0x03;
											Massage_Return.detail.Order=0x12;
											Massage_Return.detail.Return_Data=0x43;
											Massage_Return.detail.SumCheck=(uint8_t)(Massage_Return.detail.Order+Massage_Return.detail.Return_Data);
											//����1����
											USART1_Transmi_Data(Massage_Return.bytes,sizeof(Massage_Return));
										   break;
										 case 0x31:      //IMU���ݲ�ѯ
											IMU_DataFrequency=check_inform.data[4];
											break;
										 case 0x32:    //���������ݽ���У��
										   
												if(check_inform.data[4]==0x00)  //��¼����������
												{
													//===============================�����ػ�������������Ѿ�����============================//
													Massage_Return_set.detail.Head1=0xCC;
													Massage_Return_set.detail.Head2=0x33;
													Massage_Return_set.detail.Lenghth=0x03;
													Massage_Return_set.detail.Order=0x32;
													Massage_Return_set.detail.Return_Data=0x00;
													Massage_Return_set.detail.SumCheck=(uint8_t)(Massage_Return_set.detail.Order+Massage_Return_set.detail.Return_Data);
													//����1��������
													USART1_Transmi_Data(Massage_Return_set.bytes,sizeof(Massage_Return_set));
													//HAL_UART_Transmit_IT(&huart1,Massage_Return_set.bytes,sizeof(Massage_Return_set));				
													//================================end=============================================//
													
												}
												else if(check_inform.data[4]==0x01) //��¼���������ݣ������Ӧ�ı���ϵ�����洢��Flash��
												{
													//===============================�����ػ�������������Ѿ�����============================//
													Massage_Return_set.detail.Head1=0xCC;
													Massage_Return_set.detail.Head2=0x33;
													Massage_Return_set.detail.Lenghth=0x03;
													Massage_Return_set.detail.Order=0x32;
													Massage_Return_set.detail.Return_Data=0x01;
													Massage_Return_set.detail.SumCheck=(uint8_t)(Massage_Return_set.detail.Order+Massage_Return_set.detail.Return_Data);
													//����1����
													USART1_Transmi_Data(Massage_Return_set.bytes,sizeof(Massage_Return_set));
												}
											 break;
											case 0x33:
												if(check_inform.data[4]==0x00)  //��¼����������
												{
													/*Distance_L_check=Distance_check;
													//===============================�����ػ�������������Ѿ�����============================//
													//===============================�����ػ�������������Ѿ�����============================//
													Message_Return_Odom.detail.Head1=0xCC;
													Message_Return_Odom.detail.Head2=0x33;
													Message_Return_Odom.detail.Lenghth=0x04;
													Message_Return_Odom.detail.Order=0x33;
													Message_Return_Odom.detail.Return_Data=0x00;
													Message_Return_Odom.detail.Distance=0;
													Message_Return_Odom.detail.SumCheck=(uint8_t)(Message_Return_Odom.detail.Order+Message_Return_Odom.detail.Return_Data+Message_Return_Odom.detail.Distance);
													HAL_UART_Transmit_IT(&huart1,Message_Return_Odom.bytes,sizeof(Message_Return_Odom));	*/			
												   //================================end=============================================//				
												   //================================end=============================================//
													
											   }
												else if(check_inform.data[4]==0x01) 
												{
													
													//===============================�����ػ�������������Ѿ�����============================//
													Message_Return_Odom.detail.Head1=0xCC;
													Message_Return_Odom.detail.Head2=0x33;
													Message_Return_Odom.detail.Lenghth=0x04;
													Message_Return_Odom.detail.Order=0x33;
													Message_Return_Odom.detail.Return_Data=0x01;
													Message_Return_Odom.detail.Distance=0;
													Message_Return_Odom.detail.SumCheck=(uint8_t)(Message_Return_Odom.detail.Order+Message_Return_Odom.detail.Return_Data+Message_Return_Odom.detail.Distance);
													USART1_Transmi_Data(Message_Return_Odom.bytes,sizeof(Message_Return_Odom));	
												}					
											break;
											case 0x40:
												if((check_inform.data[4]==0x01) && (PlatformWorkingFlag == 0))//�Զ�ģʽ
												{
														platform_mode_flag = 1;//��̨�������Զ�ģʽ
														switch(check_inform.data[5])//2ͣ��1�ϣ�0��
														{
															case 0://����
																PlatformState_1=0;
															break;
															case 1://����
																PlatformState_1=1;
															break;
															case 2://ֹͣ
																PlatformState_1=2;
															break;
														}

														PlatformCFromPC_1=check_inform.data[7];//������λ���ļ���
														PlatformCFromPC_1=(PlatformCFromPC_1<<8)+check_inform.data[6];//����λ�Ǹߣ�����λ�ǵ�		

														PlatformState = PlatformState_1;

														for(send_num_order_return = 0; send_num_order_return  < 1; send_num_order_return ++)
														{
															Massage_Return_Platform.detail.Head1=0xCC;
															Massage_Return_Platform.detail.Head2=0x33;
															Massage_Return_Platform.detail.Lenghth=0x06;
															Massage_Return_Platform.detail.order=0x40;
															Massage_Return_Platform.detail.Mode=0x01;
															Massage_Return_Platform.detail.Return_Data=0x41;//���յ�ָ��
															Massage_Return_Platform.detail.Hight=PlatformC_1;//
															Massage_Return_Platform.detail.SumCheck=(uint8_t)(Massage_Return_Platform.bytes[3]+\
																								Massage_Return_Platform.bytes[4]+Massage_Return_Platform.bytes[5]+\
																								Massage_Return_Platform.bytes[6]+Massage_Return_Platform.bytes[7]);
															USART1_Transmi_Data(Massage_Return_Platform.bytes,sizeof(Massage_Return_Platform));	
														}

												}
												else if (check_inform.data[4]==0x00)//�ֶ�ģʽ
												{
													platform_mode_flag = 0;
														switch(check_inform.data[5])//2ͣ��1�ϣ�0�£�3���ͼ���ֵ
														{
															case 0://����
																PlatformState_1=0;
															break;
															case 1://����
																PlatformState_1=1;
															break;
															case 2://ֹͣ
																PlatformState_1=2;
															break;
															case 3://���ͼ���ֵ
																PlatformState_1=3;
															break;
														}

														PlatformCFromPC_1=check_inform.data[7];//������λ���ļ���
														PlatformCFromPC_1=(PlatformCFromPC_1<<8)+check_inform.data[6];//����λ�Ǹߣ�����λ�ǵ�		

														PlatformState = PlatformState_1;

														for(send_num_order_return = 0; send_num_order_return  < 1; send_num_order_return ++)
														{
															Massage_Return_Platform.detail.Head1=0xCC;
															Massage_Return_Platform.detail.Head2=0x33;
															Massage_Return_Platform.detail.Lenghth=0x06;
															Massage_Return_Platform.detail.order=0x40;
															Massage_Return_Platform.detail.Mode=0x00;
															Massage_Return_Platform.detail.Return_Data=0x41;//���յ�ָ��
															Massage_Return_Platform.detail.Hight=PlatformC_1;//
															Massage_Return_Platform.detail.SumCheck=(uint8_t)(Massage_Return_Platform.bytes[3]+\
																								Massage_Return_Platform.bytes[4]+Massage_Return_Platform.bytes[5]+\
																								Massage_Return_Platform.bytes[6]+Massage_Return_Platform.bytes[7]);
															USART1_Transmi_Data(Massage_Return_Platform.bytes,sizeof(Massage_Return_Platform));	
														}
												}
												break;	
										 default :
											//Output_Error(Undefined_Order_Error);           //��Чָ��
											break;
                                }
                            }
      
                        }
                     }
  
                    }


                }

            }

        }


     }
   }

}


void UltrasonicSend(void)
{
	extern u16 DistanceCon[9];//1 2 3 4 5 6 7 8 ��test.c�ж��壬�ڴ˴������ⲿ��������
    Ultrasonic_Massage  TransP_Ultrasonic;   //Ultrasonic_Massage ����������ָ��
    memset(&TransP_Ultrasonic,0,sizeof(Ultrasonic_Massage));
      //1����������Ϣ�ϴ� 
	TransP_Ultrasonic.detail.Head1=0xCC;//����������ָ��ָ�򡪡�>��������ṹ������е�Head��Ա
	TransP_Ultrasonic.detail.Head2=0x33;
	TransP_Ultrasonic.detail.Lenghth=0x12;//ʮ����18 ���Ȱ�������λ+Length+Order
	TransP_Ultrasonic.detail.Order=0x04;//������0x04
	TransP_Ultrasonic.detail.Ultrasonic1=DistanceCon[1];
	TransP_Ultrasonic.detail.Ultrasonic2=DistanceCon[2];
	TransP_Ultrasonic.detail.Ultrasonic3=DistanceCon[3];
	TransP_Ultrasonic.detail.Ultrasonic4=DistanceCon[4];
	TransP_Ultrasonic.detail.Ultrasonic5=DistanceCon[5];
	TransP_Ultrasonic.detail.Ultrasonic6=DistanceCon[6];
	TransP_Ultrasonic.detail.Ultrasonic7=DistanceCon[7];
	TransP_Ultrasonic.detail.Ultrasonic8=DistanceCon[8];
	TransP_Ultrasonic.detail.SumCheck=(uint8_t)(TransP_Ultrasonic.detail.Order+TransP_Ultrasonic.bytes[4]+TransP_Ultrasonic.bytes[5]+ \
																						TransP_Ultrasonic.bytes[6]+TransP_Ultrasonic.bytes[7]+ \
																						TransP_Ultrasonic.bytes[8]+TransP_Ultrasonic.bytes[9]+ \
					                                  TransP_Ultrasonic.bytes[10]+TransP_Ultrasonic.bytes[11]+ \
																						TransP_Ultrasonic.bytes[12]+TransP_Ultrasonic.bytes[13]+ \
																						TransP_Ultrasonic.bytes[14]+TransP_Ultrasonic.bytes[15]+ \
					                                  TransP_Ultrasonic.bytes[16]+TransP_Ultrasonic.bytes[17]+ \
																						TransP_Ultrasonic.bytes[18]+TransP_Ultrasonic.bytes[19]);
    USART1_Transmi_Data(TransP_Ultrasonic.bytes,sizeof(TransP_Ultrasonic.bytes));	
}


void TransPCarMotionstatus(void)
{
	Motion_status_Massage TransP_Car_Motion_status;
    memset(&TransP_Car_Motion_status,0,sizeof(Motion_status_Massage));
	//2���˶�ƽ̨��Ϣ�ϴ�(���������Ϣ�ϴ�)  order��0x08
	TransP_Car_Motion_status.detail.Head1=0xCC;//����������ָ��ָ�򡪡�>��������ṹ������е�Head��Ա
	TransP_Car_Motion_status.detail.Head2=0x33;
	TransP_Car_Motion_status.detail.Lenghth=0x0A;
	TransP_Car_Motion_status.detail.Order=0x08;//�����Ϣ0x08
	TransP_Car_Motion_status.detail.LED_1=0x00;
	TransP_Car_Motion_status.detail.LED_2=0x00;
	TransP_Car_Motion_status.detail.LED_3=0x00;
	TransP_Car_Motion_status.detail.LED_4=0x00;
	//TransP_Car_Motion_status->detail.LED_5=0;
	TransP_Car_Motion_status.detail.Charge=0x01;//��翪��״̬ 0x00�ر�״̬ 0x01��״̬
	TransP_Car_Motion_status.detail.Charge_status=Whether_Charge;//�Ƿ��� 0x00������ 0x02���ڳ�� 0x04��Ҫ���
	TransP_Car_Motion_status.detail.Power=Electric_Quantity_Percentage;//�����ٷֱ�
	TransP_Car_Motion_status.detail.Error=0x00;//(0&0xEF)|flashErrorFlag);
	TransP_Car_Motion_status.detail.SumCheck=(uint8_t)(TransP_Car_Motion_status.detail.Order+TransP_Car_Motion_status.detail.LED_1+  \
																							 TransP_Car_Motion_status.detail.LED_2+TransP_Car_Motion_status.detail.LED_3+  \
																							 TransP_Car_Motion_status.detail.LED_4+  \
																			 TransP_Car_Motion_status.detail.Charge+TransP_Car_Motion_status.detail.Charge_status+  \
																			 TransP_Car_Motion_status.detail.Power+TransP_Car_Motion_status.detail.Error);
    USART1_Transmi_Data(TransP_Car_Motion_status.bytes,sizeof(TransP_Car_Motion_status.bytes));
}

void ImuaDataSend(void)
{
    IMU_Data_inf SendP_Data_IMU;
    memset(&SendP_Data_IMU,0,sizeof(IMU_Data_inf));
    SendP_Data_IMU.Detial.Head1=0xCC;
   	SendP_Data_IMU.Detial.Head2=0x33;
	SendP_Data_IMU.Detial.Lenghth=0x0E;
	SendP_Data_IMU.Detial.Order=0x31;
	SendP_Data_IMU.Detial.Roll =Roll;
	SendP_Data_IMU.Detial.Pitch =Pitch;
	SendP_Data_IMU.Detial.Yaw =Yaw;
	SendP_Data_IMU.Detial.SumCheck=0x00;

	int i=3;
	for(i=3;i<16;i++)
	{
		SendP_Data_IMU.Detial.SumCheck+=SendP_Data_IMU.bytes[i];
	}

	USART1_Transmi_Data(SendP_Data_IMU.bytes,sizeof(SendP_Data_IMU.bytes));	
}

void GasSend(void)
{	
	//���崫������Ϣ�ϴ�
	extern u32 CO2value;//gas.c��ȫ�ֶ��壬�ڴ˴������ⲿ��������
	extern u32 SO2value;//gas.c��ȫ�ֶ��壬�ڴ˴������ⲿ��������
	extern u32 COvalue;//gas.c��ȫ�ֶ��壬�ڴ˴������ⲿ��������
	Gas_Message TransP_Gas;//Gas_Message* ���崫������Ϣ����������ָ�롣ָ����ΪTransP_Gas
	memset(&TransP_Gas,0,sizeof(Gas_Message));
	TransP_Gas.detail.Head1=0xCC;//����������ָ��ָ�򡪡�>��������ṹ������е�Head��Ա
					TransP_Gas.detail.Head2=0x33;
					TransP_Gas.detail.Lenghth=0x0E;//ʮ����14 ���Ȱ�������λ+Length+Order
					TransP_Gas.detail.Order=0x41;//����0x41
					TransP_Gas.detail.CO=COvalue;
					TransP_Gas.detail.CO2=CO2value;
					TransP_Gas.detail.SO2=SO2value;
					
				TransP_Gas.detail.SumCheck=(uint8_t)(TransP_Gas.detail.Order+TransP_Gas.bytes[4]+TransP_Gas.bytes[5]+ \
																						TransP_Gas.bytes[6]+TransP_Gas.bytes[7]+ \
																						TransP_Gas.bytes[8]+TransP_Gas.bytes[9]+ \
					                                  TransP_Gas.bytes[10]+TransP_Gas.bytes[11]+ \
																						TransP_Gas.bytes[12]+TransP_Gas.bytes[13]+ \
																						TransP_Gas.bytes[14]+TransP_Gas.bytes[15]);
		USART1_Transmi_Data(TransP_Gas.bytes,sizeof(TransP_Gas.bytes));	
}

void Massage_Timing_To_Pc(void)
{   
    if(messagetopcCnt>MESSAGETOPCCNT)
    { 
		static int MESSAGE_NUM = 1;
      	messagetopcCnt=0;
		switch(MESSAGE_NUM)
		{
			case 1:
				TransPCarMotionstatus();
				MESSAGE_NUM = 2;
			break;
			case 2:
				UltrasonicSend();
				MESSAGE_NUM = 3;
			break;
			case 3:
				ImuaDataSend();
				MESSAGE_NUM = 4;
			break;
			case 4:
				GasSend();
				MESSAGE_NUM = 1;
			break;
		}
    }

}







