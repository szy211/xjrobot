#include "can_drive.h"
#include "stdint.h"
#include "can.h"
#include "delay.h"

unsigned char CAN1_Send(CanTxMsg *message)
{
	unsigned char i;
	uint8_t mbox;
	uint16_t j=0;
	uint8_t Data[8];
	for(i=0;i<message->len;i++)
	{
		Data[i] = message->data[i];
	}			  	 						       
    mbox=CAN1_Tx_Msg((uint32_t)(message->cob_id),0,0,message->len,Data);//CANͨ�ŷ�����Ϣ��ʽ
	while((CAN1_Tx_Staus(mbox)!=0X07)&&(j<0XFFF))j++;//�ȴ����ͽ���
	if(j>=0XFFF)return 1;							//����ʧ��
	return 0;										//���ͳɹ�;

}



//д������ 0x06
void Motor_Controlword(uint16_t COD_ID)
{
	CanTxMsg TxMessage = TxMessage_Init;
	TxMessage.cob_id=COD_ID;
	TxMessage.ide=0;
	TxMessage.rtr=0;
	TxMessage.len=8;
	TxMessage.data[0]=0x2B;
	TxMessage.data[1]=0x40;
	TxMessage.data[2]=0x60;
	TxMessage.data[3]=0x00;
	TxMessage.data[4]=0x06;
	TxMessage.data[5]=0x00;
	TxMessage.data[6]=0x00;
	TxMessage.data[7]=0x00;
	CAN1_Send(&TxMessage);
}

//ʹ�ܵ�� 0X07 ����������0x0f
void Enable_Motor_Operat(uint16_t COD_ID)
{
	CanTxMsg EN_TxMessage = TxMessage_Init;
	EN_TxMessage.cob_id=COD_ID;
	EN_TxMessage.ide=0;
	EN_TxMessage.rtr=0;
	EN_TxMessage.len=8;
	
	//ʹ��0x06
	EN_TxMessage.data[0]=0x2B;
	EN_TxMessage.data[1]=0x40;
	EN_TxMessage.data[2]=0x60;
	EN_TxMessage.data[3]=0x00;
	EN_TxMessage.data[4]=0x07;
	EN_TxMessage.data[5]=0x00;
	EN_TxMessage.data[6]=0x00;
	EN_TxMessage.data[7]=0x00;
	CAN1_Send(&EN_TxMessage);
	delay_ms(500);
	
    //��������  0x0f
	EN_TxMessage.data[0]=0x2B;
	EN_TxMessage.data[1]=0x40;
	EN_TxMessage.data[2]=0x60;
	EN_TxMessage.data[3]=0x00;
	EN_TxMessage.data[4]=0x0F;
	EN_TxMessage.data[5]=0x00;
	EN_TxMessage.data[6]=0x00;
	EN_TxMessage.data[7]=0x00;
	CAN1_Send(&EN_TxMessage);
	delay_ms(500);
}


//��ʼ����� 
void Motor_Drive_Init(uint16_t COD_ID1,uint16_t COD_ID2,uint16_t COD_ID3,uint16_t COD_ID4)
{
	delay_ms(20);
	Motor_Controlword(COD_ID1);
	delay_ms(20);
	Motor_Controlword(COD_ID2);
	delay_ms(20);
	Motor_Controlword(COD_ID3);
	delay_ms(20);
	Motor_Controlword(COD_ID4);
	delay_ms(20);
	Enable_Motor_Operat(COD_ID1);
	delay_ms(20);
	Enable_Motor_Operat(COD_ID2);
	delay_ms(20);
	Enable_Motor_Operat(COD_ID3);
	delay_ms(20);
	Enable_Motor_Operat(COD_ID4);
	delay_ms(20);
}

  
//�����ٶ�  ���4500ת/��  ��������0X60FF
void Motor_Velocity(uint16_t COD_ID, uint16_t speed)  // 0X60FF
{
	CanTxMsg Ve_TxMessage=TxMessage_Init;
	Ve_TxMessage.cob_id=COD_ID;
	Ve_TxMessage.ide=0;
	Ve_TxMessage.rtr=0;
	Ve_TxMessage.len=8;
	
	//���ݳ����ĸ��ֽ�data[0]=0x23   
	//���ݳ���2���ֽ�data[0]=0x2B    ע���λ��λ����
	
	
	Ve_TxMessage.data[0]=0x2B;
	Ve_TxMessage.data[1]=0xFF;
	Ve_TxMessage.data[2]=0x60;
	Ve_TxMessage.data[3]=0x00;
	Ve_TxMessage.data[4]=(uint8_t)(speed);
	Ve_TxMessage.data[5]=(uint8_t)(speed>>8);
	Ve_TxMessage.data[6]=0;
	Ve_TxMessage.data[7]=0;
	CAN1_Send(&Ve_TxMessage);
	delay_ms(2);
}


//��������������  ��������0x6063
void Motor_Position_Request(uint16_t COD_ID)
{
	CanTxMsg Pos_TxMessage=TxMessage_Init;
	Pos_TxMessage.cob_id=COD_ID;
	Pos_TxMessage.ide=0;
	Pos_TxMessage.rtr=0;
	Pos_TxMessage.len=8;
	Pos_TxMessage.data[0]=0x40;
	Pos_TxMessage.data[1]=0x63;
	Pos_TxMessage.data[2]=0x60;
	Pos_TxMessage.data[3]=0x00;
	Pos_TxMessage.data[4]=0x00;
	Pos_TxMessage.data[5]=0x00;
	Pos_TxMessage.data[6]=0x00;
	Pos_TxMessage.data[7]=0x00;
	CAN1_Send(&Pos_TxMessage);
//	delay_ms(10);
}










