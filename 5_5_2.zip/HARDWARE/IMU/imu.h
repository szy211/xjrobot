#ifndef __IMU_H
#define __IMU_H

#include "sys.h"
#include "usart.h"

#define Pi 3.1415926535898f

extern uint16_t IMU_Command_time;
extern float Last_Yaw,Now_Yaw,Error;
extern uint8_t uart4_Rx_data;
extern uint8_t IMU_Init_Flag;	 
extern float Yaw_0state,IMU_State,IMU_State_Rad,Pre_IMU_State_Rad;	 
extern float Pitch,Yaw,Roll;	

//void ReaData_Command(void);
void IMU_DataReceive(void);


void IMU_DataAnalyse(u8 *Point, u8 num);
void Yaw_Error(void);
void IMU_Init(void);
void IMU_Now_State(void);

uint8_t checksum(void);



typedef struct {
	
	__IO float Roll;
	__IO float Pitch;
	__IO float Yaw;
	
}IMU_Orientation;
typedef union
{
	IMU_Orientation Detail;
	uint8_t buff[12];
}IMU_Data;

#endif


