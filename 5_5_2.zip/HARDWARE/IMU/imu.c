
 #include "sys.h"
 #include "delay.h" 
 #include "imu.h"

 #include "usart.h"  
 #include "sdram.h"  

 
 IMU_Data DATA_IMU;
 
 
 int IMU_count;
uint16_t IMU_sum=0;
uint8_t checksum_IMU=0;
float Pitch,Yaw,Roll;


 void IMU_DataAnalyse(u8 *Point, u8 num)  //��uint_t Ϊu8
{
	int t=0;
	if(Point[0]==0xFA&&Point[1]==0xFF)
	{
		IMU_sum=0;
		for(IMU_count=1;IMU_count<19;IMU_count++)  //У��� 1��18λ  ��ȥ��һλ��������֮��
		{
			IMU_sum+=Point[IMU_count];
		}
		checksum_IMU=(uint8_t)(0x100-(uint8_t)IMU_sum);
		if(checksum_IMU==Point[19])
		{
			//Roll
			DATA_IMU.buff[0]=Point[10];
			DATA_IMU.buff[1]=Point[9];
			DATA_IMU.buff[2]=Point[8];
			DATA_IMU.buff[3]=Point[7];
			//Pitch
			DATA_IMU.buff[4]=Point[14];
			DATA_IMU.buff[5]=Point[13];
			DATA_IMU.buff[6]=Point[12];
			DATA_IMU.buff[7]=Point[11];
			//Yaw
			DATA_IMU.buff[8]=Point[18];
			DATA_IMU.buff[9]=Point[17];
			DATA_IMU.buff[10]=Point[16];
			DATA_IMU.buff[11]=Point[15];
			DATA_IMU.Detail.Yaw=DATA_IMU.Detail.Yaw;

			//ת����float �Ͷ�ȡ
			Roll=(DATA_IMU.Detail.Roll)* Pi/180.0f;
			Pitch=(DATA_IMU.Detail.Pitch)* Pi/180.0f;
			Yaw=(DATA_IMU.Detail.Yaw)* Pi/180.0f;
			
			
			IMUDatareceiveCount=0;  //���ڼ���
			for(t=0;t<54;t++)    //�������������0
			{
				 IMUDatareceive[t]=0;
			}
		}
	}
}


float Pre_Yaw=0,Now_Yaw=0,Error=0;

void Yaw_Error(void)
{
	Pre_Yaw=Now_Yaw;
	Now_Yaw=DATA_IMU.Detail.Yaw;
	Error=Now_Yaw-Pre_Yaw;
	if(Error>180)
		Error=360-Error;
	if(Error<-180)
		Error=-360-Error;
	Error = Error * Pi/180.0f;
}



